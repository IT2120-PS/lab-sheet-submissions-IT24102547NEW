setwd("C:\\Users\\Sasuni\\Desktop\\PS_Lab3")

student_data <- read.csv("Exercise.csv", header = TRUE)
fix(student_data)
names(student_data) <- c("Age", "Gender", "Accommodation")
student_data$Gender <- factor(student_data$Gender, c(1,2),c("Male","Female"))
student_data$Accommodation <- factor(student_data$Accommodation, c(1,2,3), c("Home","Boarded","Lodging"))
attach(student_data)


summary(student_data$Age)
hist(Age, main="Histogram for age")

gender.freq <- table(student_data$Gender)
gender.freq

barplot(gender.freq, main ="Bar chart for Gender", ylab = "frequency", xlab = "Gender")
abline(h=0)

boxplot(Age ~ Accommodation, main = "Age by Accommodation Type",xlab = "Accommodation Type",ylab = "Age")