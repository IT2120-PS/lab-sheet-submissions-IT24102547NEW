getwd()
setwd("C:\\Users\\IT24101206\\Desktop\\IT24101206")
dbinom(40,44,0.92)
pbinom(35,44,0.92,lower.tail =TRUE)
1- pbinom(37,44,0.92,lower.tail= TRUE)
pbinom(37,44,0.92, lower.tail= FALSE)
pbinom(42,44,0.92,lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)
dpois(6,5)
ppois(6,5,lower.tail=FALSE)




##exercise

##Q1 part 1: random variable X has the binomial distrubution with n= 50 and p=0.85

## Q1 part 2: probability that at least 47 students passed
## =>P(X>=47) = 1-P(X<=46)
P_47<-1 -pbinom(46,50,0.85, lower.tail=TRUE)
P_47

##Q2 part 1: Random variable X= number of calls recieved in an hour
## part 2: Distribution of X: Poisson(12)
## part 3: Probability that exactly 15 calls are received in an hour
P_15 <- dpois(15,12)
P_15

